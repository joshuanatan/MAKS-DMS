<html>
    <head>
    
    </head>
    <body>
        <h1>Yay bisa hehehe</h1>
        <table>
            <tr>
                <td>Numbers</td>
            </tr>
            <?php for($a = 0; $a<100; $a++):?>
            <tr>
                <td><?php echo $a+1;?></td>
            </tr>
            <?php endfor;?>
        </table>
    </body>
</html>