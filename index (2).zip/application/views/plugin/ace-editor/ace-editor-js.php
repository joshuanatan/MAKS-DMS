<script src="<?php echo base_url();?>assets/global/vendor/ace/ace.js"></script>
<script src="<?php echo base_url();?>assets/global/js/Plugin/ace-editor.js"></script>