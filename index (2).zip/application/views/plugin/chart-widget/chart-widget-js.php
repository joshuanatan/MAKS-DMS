
<script src="<?php echo base_url();?>assets/global/vendor/sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/chartist/chartist.min.js"></script>
<script src="<?php echo base_url();?>assets/global/vendor/matchheight/jquery.matchHeight-min.js"></script>
<script src="<?php echo base_url();?>assets/global/js/Plugin/matchheight.js"></script>
<!--<script src="<?php echo base_url();?>assets/assets/examples/js/widgets/chart.js"></script>-->